package com.geosita.laoy.system.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.geosita.laoy.system.model.MemberPackageBean;

/**
 * IMemberPackageDao :(描述)<br/>
 * date: 2017年02月08日 15:52:26<br/>
 * @source generate create
 * @author maoxiaoming
 */
public interface IMemberPackageDao{
	
	/**
	 * 
	 * insert:插入记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	int insertMemberPackage(MemberPackageBean memberPackageBean);
	
	/**
	 * 
	 * update:修改记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	int updateMemberPackage(MemberPackageBean memberPackageBean);
	
	/**
	 * 
	 * deleteMemberPackage:删除记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	int deleteMemberPackage(@Param("id") Long id);
	
	/**
	 * 
	 * getMemberPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	MemberPackageBean getMemberPackageById(@Param("id") Long id);
	
	/**
	 * 
	 *  findMemberPackagePageCount:查询记录数. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	long findMemberPackagePageCount(MemberPackageBean memberPackageBean);
	
	/**
	 * 
	 * findMemberPackagePage:分页查询数据. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	List<MemberPackageBean> findMemberPackagePage(MemberPackageBean memberPackageBean);

}
