package com.geosita.laoy.system.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.geosita.laoy.system.model.UserPackageBean;

/**
 * IUserPackageDao :(描述)<br/>
 * date: 2017年02月08日 15:52:25<br/>
 * @source generate create
 * @author maoxiaoming
 */
public interface IUserPackageDao{
	
	/**
	 * 
	 * insert:插入记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	int insertUserPackage(UserPackageBean userPackageBean);
	
	/**
	 * 
	 * update:修改记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	int updateUserPackage(UserPackageBean userPackageBean);
	
	/**
	 * 
	 * deleteUserPackage:删除记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	int deleteUserPackage(@Param("id") Long id);
	
	/**
	 * 
	 * getUserPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	UserPackageBean getUserPackageById(@Param("id") Long id);
	
	/**
	 * 
	 *  findUserPackagePageCount:查询记录数. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	long findUserPackagePageCount(UserPackageBean userPackageBean);
	
	/**
	 * 
	 * findUserPackagePage:分页查询数据. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	List<UserPackageBean> findUserPackagePage(UserPackageBean userPackageBean);

}
