package com.geosita.laoy.system.model;

import com.geosita.laoy.common.util.page.BasePage;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
/**
 * UserPackageBean :(描述)<br/>
 * date: 2017年02月08日 15:52:25<br/>
 * @source generate create
 * @author maoxiaoming
 */
public class UserPackageBean extends BasePage<UserPackageBean>{
	
	/**
	 * 用户套餐主键
	 */
	private Integer userPackageId;
	/**
	 * 用户主键
	 */
	private Integer userId;
	/**
	 * 套餐主键
	 */
	private Integer packageId;
	/**
	 * 已用职位数
	 */
	private Integer usedJobNumber;
	/**
	 * 已用精选简历数
	 */
	private Integer usedResumeNumber;
	/**
	 * 已用专业猎头数
	 */
	private Integer usedHeadhuntingNumber;
	/**
	 * 已用HR在线课程数
	 */
	private Integer usedCourseNumber;
	/**
	 * 已用招顾服务数
	 */
	private Integer usedServiceNumber;
	/**
	 * 失效日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8") 
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private Date expiryDate;
	/**
	 * 创建人
	 */
	private Integer createUserId;
	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8") 
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private Date createDate;
	/**
	 * 最后修改时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8") 
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private Date lastModifyDate;
	/**
	 * 记录状态(0:停用 1：正常 2：失效)
	 */
	private Integer recordStatus;
	
		/*	*/
	public void setUserPackageId(Integer value) {
		this.userPackageId = value;
	}
	
	public Integer getUserPackageId() {
		return this.userPackageId;
	}
		/*	*/
	public void setUserId(Integer value) {
		this.userId = value;
	}
	
	public Integer getUserId() {
		return this.userId;
	}
		/*	*/
	public void setPackageId(Integer value) {
		this.packageId = value;
	}
	
	public Integer getPackageId() {
		return this.packageId;
	}
		/*	*/
	public void setUsedJobNumber(Integer value) {
		this.usedJobNumber = value;
	}
	
	public Integer getUsedJobNumber() {
		return this.usedJobNumber;
	}
		/*	*/
	public void setUsedResumeNumber(Integer value) {
		this.usedResumeNumber = value;
	}
	
	public Integer getUsedResumeNumber() {
		return this.usedResumeNumber;
	}
		/*	*/
	public void setUsedHeadhuntingNumber(Integer value) {
		this.usedHeadhuntingNumber = value;
	}
	
	public Integer getUsedHeadhuntingNumber() {
		return this.usedHeadhuntingNumber;
	}
		/*	*/
	public void setUsedCourseNumber(Integer value) {
		this.usedCourseNumber = value;
	}
	
	public Integer getUsedCourseNumber() {
		return this.usedCourseNumber;
	}
		/*	*/
	public void setUsedServiceNumber(Integer value) {
		this.usedServiceNumber = value;
	}
	
	public Integer getUsedServiceNumber() {
		return this.usedServiceNumber;
	}
		/*
	public String getExpiryDateString() {
		return DateConvertUtils.format(getExpiryDate(), FORMAT_EXPIRY_DATE);
	}
	public void setExpiryDateString(String value) {
		setExpiryDate(DateConvertUtils.parse(value, FORMAT_EXPIRY_DATE,Date.class));
	}
	
			*/
	public void setExpiryDate(Date value) {
		this.expiryDate = value;
	}
	
	public Date getExpiryDate() {
		return this.expiryDate;
	}
		/*	*/
	public void setCreateUserId(Integer value) {
		this.createUserId = value;
	}
	
	public Integer getCreateUserId() {
		return this.createUserId;
	}
		/*
	public String getCreateDateString() {
		return DateConvertUtils.format(getCreateDate(), FORMAT_CREATE_DATE);
	}
	public void setCreateDateString(String value) {
		setCreateDate(DateConvertUtils.parse(value, FORMAT_CREATE_DATE,Date.class));
	}
	
			*/
	public void setCreateDate(Date value) {
		this.createDate = value;
	}
	
	public Date getCreateDate() {
		return this.createDate;
	}
		/*
	public String getLastModifyDateString() {
		return DateConvertUtils.format(getLastModifyDate(), FORMAT_LAST_MODIFY_DATE);
	}
	public void setLastModifyDateString(String value) {
		setLastModifyDate(DateConvertUtils.parse(value, FORMAT_LAST_MODIFY_DATE,Date.class));
	}
	
			*/
	public void setLastModifyDate(Date value) {
		this.lastModifyDate = value;
	}
	
	public Date getLastModifyDate() {
		return this.lastModifyDate;
	}
		/*	*/
	public void setRecordStatus(Integer value) {
		this.recordStatus = value;
	}
	
	public Integer getRecordStatus() {
		return this.recordStatus;
	}
}
