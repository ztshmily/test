package com.geosita.laoy.system.model;

import com.geosita.laoy.common.util.page.BasePage;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
/**
 * MemberPackageBean :(描述)<br/>
 * date: 2017年02月08日 15:52:26<br/>
 * @source generate create
 * @author maoxiaoming
 */
public class MemberPackageBean extends BasePage<MemberPackageBean>{
	
	/**
	 * 套餐主键
	 */
	private Integer packageId;
	/**
	 * 套餐名称
	 */
	private String packageName;
	/**
	 * 套餐费用
	 */
	private BigDecimal packageFee;
	/**
	 * 套餐期限（单位是月）
	 */
	private Integer packageTimeLimit;
	/**
	 * 发布职位数
	 */
	private Integer jobNumber;
	/**
	 * 精选简历数
	 */
	private Integer resumeNumber;
	/**
	 * 专业猎头数
	 */
	private Integer headhuntingNumber;
	/**
	 * HR在线课程数
	 */
	private Integer courseNumber;
	/**
	 * 招顾服务数
	 */
	private Integer serviceNumber;
	/**
	 * 创建人
	 */
	private Integer createUserId;
	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8") 
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private Date createDate;
	/**
	 * 最后修改时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8") 
	@DateTimeFormat(pattern = "yyyy-MM-dd") 
	private Date lastModifyDate;
	/**
	 * 记录状态(0:停用 1：正常)
	 */
	private Integer recordStatus;
	
		/*	*/
	public void setPackageId(Integer value) {
		this.packageId = value;
	}
	
	public Integer getPackageId() {
		return this.packageId;
	}
		/*	*/
	public void setPackageName(String value) {
		this.packageName = value;
	}
	
	public String getPackageName() {
		return this.packageName;
	}
		/*	*/
	public void setPackageFee(BigDecimal value) {
		this.packageFee = value;
	}
	
	public BigDecimal getPackageFee() {
		return this.packageFee;
	}
		/*	*/
	public void setPackageTimeLimit(Integer value) {
		this.packageTimeLimit = value;
	}
	
	public Integer getPackageTimeLimit() {
		return this.packageTimeLimit;
	}
		/*	*/
	public void setJobNumber(Integer value) {
		this.jobNumber = value;
	}
	
	public Integer getJobNumber() {
		return this.jobNumber;
	}
		/*	*/
	public void setResumeNumber(Integer value) {
		this.resumeNumber = value;
	}
	
	public Integer getResumeNumber() {
		return this.resumeNumber;
	}
		/*	*/
	public void setHeadhuntingNumber(Integer value) {
		this.headhuntingNumber = value;
	}
	
	public Integer getHeadhuntingNumber() {
		return this.headhuntingNumber;
	}
		/*	*/
	public void setCourseNumber(Integer value) {
		this.courseNumber = value;
	}
	
	public Integer getCourseNumber() {
		return this.courseNumber;
	}
		/*	*/
	public void setServiceNumber(Integer value) {
		this.serviceNumber = value;
	}
	
	public Integer getServiceNumber() {
		return this.serviceNumber;
	}
		/*	*/
	public void setCreateUserId(Integer value) {
		this.createUserId = value;
	}
	
	public Integer getCreateUserId() {
		return this.createUserId;
	}
		/*
	public String getCreateDateString() {
		return DateConvertUtils.format(getCreateDate(), FORMAT_CREATE_DATE);
	}
	public void setCreateDateString(String value) {
		setCreateDate(DateConvertUtils.parse(value, FORMAT_CREATE_DATE,Date.class));
	}
	
			*/
	public void setCreateDate(Date value) {
		this.createDate = value;
	}
	
	public Date getCreateDate() {
		return this.createDate;
	}
		/*
	public String getLastModifyDateString() {
		return DateConvertUtils.format(getLastModifyDate(), FORMAT_LAST_MODIFY_DATE);
	}
	public void setLastModifyDateString(String value) {
		setLastModifyDate(DateConvertUtils.parse(value, FORMAT_LAST_MODIFY_DATE,Date.class));
	}
	
			*/
	public void setLastModifyDate(Date value) {
		this.lastModifyDate = value;
	}
	
	public Date getLastModifyDate() {
		return this.lastModifyDate;
	}
		/*	*/
	public void setRecordStatus(Integer value) {
		this.recordStatus = value;
	}
	
	public Integer getRecordStatus() {
		return this.recordStatus;
	}
}
