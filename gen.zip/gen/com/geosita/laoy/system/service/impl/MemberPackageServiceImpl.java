package com.geosita.laoy.system.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.geosita.laoy.common.util.page.Page;
import com.geosita.laoy.system.service.IMemberPackageService;
import com.geosita.laoy.system.dao.IMemberPackageDao;
import com.geosita.laoy.system.model.MemberPackageBean;
/**
 * MemberPackageServiceImpl :(描述)<br/>
 * date: 2017年02月08日 15:52:26<br/>
 * @source generate create
 * @author maoxiaoming
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class MemberPackageServiceImpl implements IMemberPackageService{

    @Autowired
    IMemberPackageDao memberPackageDao;
    
	/**
	 * insertMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int insertMemberPackage(MemberPackageBean bean){
		return memberPackageDao.insertMemberPackage(bean);
	}

	/**
	 * updateMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int updateMemberPackage(MemberPackageBean bean){
		return memberPackageDao.updateMemberPackage(bean);
	}
	
	/**
	 * deleteMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int deleteMemberPackage(Long id){
		return memberPackageDao.deleteMemberPackage(id);
	}
	
	/**
	 * 
	 * getMemberPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	public MemberPackageBean getMemberPackageById(Long id){
		return  memberPackageDao.getMemberPackageById(id);
	}

	/**
	 *  findMemberPackagePage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return List<AccessoryBean>
	 */
	public List<MemberPackageBean> findMemberPackagePage(MemberPackageBean bean, Page<MemberPackageBean> page){
		bean.init(page);//加载分页参数到bean
		List<MemberPackageBean> beans = memberPackageDao.findMemberPackagePage(bean);
		Long count = memberPackageDao.findMemberPackagePageCount(bean);
		page.setTotalCount(count);
		page.setResult(beans);
		return beans;
	}
}
