package com.geosita.laoy.system.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.geosita.laoy.common.util.page.Page;
import com.geosita.laoy.system.service.IUserPackageService;
import com.geosita.laoy.system.dao.IUserPackageDao;
import com.geosita.laoy.system.model.UserPackageBean;
/**
 * UserPackageServiceImpl :(描述)<br/>
 * date: 2017年02月08日 15:52:25<br/>
 * @source generate create
 * @author maoxiaoming
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UserPackageServiceImpl implements IUserPackageService{

    @Autowired
    IUserPackageDao userPackageDao;
    
	/**
	 * insertUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int insertUserPackage(UserPackageBean bean){
		return userPackageDao.insertUserPackage(bean);
	}

	/**
	 * updateUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int updateUserPackage(UserPackageBean bean){
		return userPackageDao.updateUserPackage(bean);
	}
	
	/**
	 * deleteUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int deleteUserPackage(Long id){
		return userPackageDao.deleteUserPackage(id);
	}
	
	/**
	 * 
	 * getUserPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	public UserPackageBean getUserPackageById(Long id){
		return  userPackageDao.getUserPackageById(id);
	}

	/**
	 *  findUserPackagePage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return List<AccessoryBean>
	 */
	public List<UserPackageBean> findUserPackagePage(UserPackageBean bean, Page<UserPackageBean> page){
		bean.init(page);//加载分页参数到bean
		List<UserPackageBean> beans = userPackageDao.findUserPackagePage(bean);
		Long count = userPackageDao.findUserPackagePageCount(bean);
		page.setTotalCount(count);
		page.setResult(beans);
		return beans;
	}
}
