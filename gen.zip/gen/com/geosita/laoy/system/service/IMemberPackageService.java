package com.geosita.laoy.system.service;

import java.util.List;

import com.geosita.laoy.common.util.page.Page;

import com.geosita.laoy.system.model.MemberPackageBean;

/**
 * IMemberPackageService :(描述)<br/>
 * date: 2017年02月08日 15:52:26<br/>
 * @source generate create
 * @author maoxiaoming
 */
public interface IMemberPackageService{

	/**
	 * insertMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int insertMemberPackage(MemberPackageBean bean);

	/**
	 * updateMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int updateMemberPackage(MemberPackageBean bean);
	
	/**
	 * deleteMemberPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return int
	 */
	public int deleteMemberPackage(Long id);
	
	/**
	 * 
	 * getMemberPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming MemberPackageBean
	 * @param memberPackageBean
	 * @date 2017年02月08日 15:52:26<br/>
	 * @return void
	 */
	public MemberPackageBean getMemberPackageById(Long id);
	
	/**
	 *  findMemberPackagePage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:26
	 * @param bean
	 * @return List<AccessoryBean>
	 */
	public List<MemberPackageBean> findMemberPackagePage(MemberPackageBean bean, Page<MemberPackageBean> page);
}
