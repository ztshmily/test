package com.geosita.laoy.system.service;

import java.util.List;

import com.geosita.laoy.common.util.page.Page;

import com.geosita.laoy.system.model.UserPackageBean;

/**
 * IUserPackageService :(描述)<br/>
 * date: 2017年02月08日 15:52:25<br/>
 * @source generate create
 * @author maoxiaoming
 */
public interface IUserPackageService{

	/**
	 * insertUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int insertUserPackage(UserPackageBean bean);

	/**
	 * updateUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int updateUserPackage(UserPackageBean bean);
	
	/**
	 * deleteUserPackage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return int
	 */
	public int deleteUserPackage(Long id);
	
	/**
	 * 
	 * getUserPackageById:根据主键查询唯一记录. <br/>
	 * @author maoxiaoming UserPackageBean
	 * @param userPackageBean
	 * @date 2017年02月08日 15:52:25<br/>
	 * @return void
	 */
	public UserPackageBean getUserPackageById(Long id);
	
	/**
	 *  findUserPackagePage:(描述). <br/>
	 * 
	 * @author maoxiaoming
	 * @date 2017年02月08日 15:52:25
	 * @param bean
	 * @return List<AccessoryBean>
	 */
	public List<UserPackageBean> findUserPackagePage(UserPackageBean bean, Page<UserPackageBean> page);
}
