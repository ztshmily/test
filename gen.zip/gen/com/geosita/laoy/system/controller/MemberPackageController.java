package com.geosita.laoy.system.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.stereotype.Controller;

import com.geosita.laoy.common.controller.BaseController;
import com.geosita.laoy.common.util.page.Page;
import com.geosita.laoy.common.util.page.PageUtil;
import com.geosita.laoy.common.vo.ModelView;
import com.geosita.laoy.common.vo.ResultMsg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import com.geosita.laoy.system.model.MemberPackageBean;
import com.geosita.laoy.system.service.IMemberPackageService;

/**
 * MemberPackageController :(描述)<br/>
 * date: 2017年02月08日 15:52:26<br/>
 * @source generate create
 * @author maoxiaoming
 */
@RestController
@EnableWebMvc
@RequestMapping("/memberPackage")
public class MemberPackageController extends BaseController{
  
    @Autowired
    IMemberPackageService memberPackageService;
	
    @RequestMapping(value = "/save", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
    public ResultMsg<Integer> addMemberPackage(MemberPackageBean bean, WebRequest request) {
        ResultMsg<Integer> result = new ResultMsg<Integer>();
        try {
	        //TODO 数据合法性校验
        	
        	//根据业务设置失败原因
	        result.setCode(ResultMsg.SYSTEM_ERROR);
	        
	        //调用数据插入的业务方法
	        Integer opResult = memberPackageService.insertMemberPackage(bean);
	        
	        //设置成功及返回结果
	        result.setResult(ResultMsg.SUCCESS, opResult);
	        return result;
        }
        catch (Exception e) {
   			logger.error("查询XX数据失败!", e);
   			result.setResultError(ResultMsg.BIZ_ERROR, "查询XX数据失败");
   		}
   		return result;
    }
    
    @RequestMapping(value = "/modify", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE })
    public ResultMsg<Integer> updateMemberPackage(MemberPackageBean bean, WebRequest request) {
        ResultMsg<Integer> result = new ResultMsg<Integer>();
        
        try {
	        //TODO 数据合法性校验
	        
	        //根据业务设置失败原因
	        result.setCode(ResultMsg.SYSTEM_ERROR);
	        
	        //调用数据插入的业务方法
	        Integer opResult = memberPackageService.updateMemberPackage(bean);
	        
	        //设置成功及返回结果
	        result.setResult(ResultMsg.SUCCESS, opResult);
	        return result;
        }
        catch (Exception e) {
   			logger.error("查询XX数据失败!", e);
   			result.setResultError(ResultMsg.BIZ_ERROR, "查询XX数据失败");
   		}
   		return result;
    }
    
    @RequestMapping(value = "/del/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
   	public ResultMsg<Integer> deleteMemberPackage(HttpServletRequest request, HttpServletResponse response,
   			@PathVariable("id") Long id) {
   		ResultMsg<Integer> result = new ResultMsg<Integer>();
   		try {
   	        //TODO 数据合法性校验
   	        
   	        //根据业务设置失败原因
	        result.setCode(ResultMsg.SYSTEM_ERROR);
   	        
   	        //调用数据插入的业务方法
   	        Integer opResult = memberPackageService.deleteMemberPackage(id);
   	        
   	        //设置成功及返回结果
   	        result.setResult(ResultMsg.SUCCESS, opResult);
   	        return result;
   		}
   		catch (Exception e) {
   			logger.error("查询XX数据失败!", e);
   			result.setResultError(ResultMsg.BIZ_ERROR, "查询XX数据失败");
   		}
   		return result;
   	}
    
    @RequestMapping(value = "/get/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResultMsg<MemberPackageBean> getMemberPackage(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("id") Long id) {
		ResultMsg<MemberPackageBean> result = new ResultMsg<MemberPackageBean>();
		try {
   	        //TODO 数据合法性校验
			
			 //根据业务设置失败原因
   	        result.setCode(ResultMsg.SYSTEM_ERROR);
   	        
   	        //调用数据插入的业务方法
   	        MemberPackageBean bean = memberPackageService.getMemberPackageById(id);
   	        
   	        //设置成功及返回结果
   	        result.setResult(ResultMsg.SUCCESS, bean);
   	        return result;
		}
		catch (Exception e) {
			logger.error("查询XX数据失败!", e);
			result.setResultError(ResultMsg.BIZ_ERROR, "查询XX数据失败");
		}
		return result;
	}
    
    @RequestMapping(value = "/list", method = RequestMethod.GET)
	@ResponseBody
	public ResultMsg<Page<MemberPackageBean>> findMemberPackagePage(MemberPackageBean bean, WebRequest request) {
		ResultMsg<Page<MemberPackageBean>> result = new ResultMsg<Page<MemberPackageBean>>();
		try {
   	        //TODO 数据合法性校验
			
			//根据业务设置失败原因
   	        result.setCode(ResultMsg.SYSTEM_ERROR);
   	        
	    	Page<MemberPackageBean> page = new Page<MemberPackageBean>(PageUtil.PAGE_SIZE).init(request);
	    	memberPackageService.findMemberPackagePage(bean, page);

	    	//设置成功及返回结果
   	        result.setResult(ResultMsg.SUCCESS, page);
   	        return result;
		
		}
		catch (Exception e) {
			logger.error("查询XX数据失败!", e);
			result.setResultError(ResultMsg.BIZ_ERROR, "查询XX数据失败");
		}
		return result;
	}
}
